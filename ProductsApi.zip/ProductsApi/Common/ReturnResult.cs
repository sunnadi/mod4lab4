public class ReturnResult<T>
{
    public bool IsSuccess { get; set; }
    public T? Result { get; set; }
    public List<string> ErrorMessage { get; set; } = new();

    public static ReturnResult<T> Ok(T result) =>
        new() { IsSuccess = true, Result = result };

    public static ReturnResult<T> Fail(params string[] errors) =>
        new() { IsSuccess = false, ErrorMessage = errors.ToList() };
}
