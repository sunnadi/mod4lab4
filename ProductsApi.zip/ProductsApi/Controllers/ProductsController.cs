using AutoMapper;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductRepository _repo;
    private readonly IMapper _mapper;

    public ProductsController(IProductRepository repo, IMapper mapper)
    {
        _repo = repo;
        _mapper = mapper;
    }

    [HttpGet]
    public async Task<ActionResult<ReturnResult<IEnumerable<ProductDto>>>> GetAll()
    {
        var products = await _repo.GetAllAsync();
        return Ok(ReturnResult<IEnumerable<ProductDto>>
            .Ok(_mapper.Map<IEnumerable<ProductDto>>(products)));
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ReturnResult<ProductDto>>> Get(int id)
    {
        var product = await _repo.GetAsync(id);
        if (product is null)
            return NotFound(ReturnResult<ProductDto>.Fail($"Товар {id} не найден"));

        return Ok(ReturnResult<ProductDto>.Ok(_mapper.Map<ProductDto>(product)));
    }

    [HttpPost]
    public async Task<ActionResult<ReturnResult<ProductDto>>> Create(ProductDto dto)
    {
        var product = _mapper.Map<Product>(dto);
        product.Id = 0;
        await _repo.CreateAsync(product);

        var result = ReturnResult<ProductDto>.Ok(_mapper.Map<ProductDto>(product));
        return CreatedAtAction(nameof(Get), new { id = product.Id }, result);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<ReturnResult<ProductDto>>> Update(int id, ProductDto dto)
    {
        var product = await _repo.GetAsync(id);
        if (product is null)
            return NotFound(ReturnResult<ProductDto>.Fail($"Товар {id} не найден"));

        _mapper.Map(dto, product);   // Category в DTO нет, поэтому остаётся прежней
        product.Id = id;
        await _repo.UpdateAsync(product);

        return Ok(ReturnResult<ProductDto>.Ok(_mapper.Map<ProductDto>(product)));
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult<ReturnResult<bool>>> Delete(int id)
    {
        if (await _repo.GetAsync(id) is null)
            return NotFound(ReturnResult<bool>.Fail($"Товар {id} не найден"));

        await _repo.DeleteAsync(id);
        return Ok(ReturnResult<bool>.Ok(true));
    }
}
