Запуск (из папки, где лежит ProductsApi.csproj):

  dotnet restore
  dotnet ef migrations add InitialCreate
  dotnet run

Откройте в браузере адрес из консоли (http://localhost:XXXX) - он перейдёт на /swagger.
База products.db создаётся автоматически при запуске (SQLite).
